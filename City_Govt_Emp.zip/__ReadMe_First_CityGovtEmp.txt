--------------------------------------------------------------------------------
                              README for 
    U.S. DEPARTMENT OF COMMERCE--ECONOMICS AND STATISTICS ADMINISTRATION 
                U.S. CENSUS BUREAU - GOVERNMENTS DIVISION 
 
          Data Base on Historical Employment of Local Governments:
                          "City_Govt_Emp" 
                            1952 - 2010
                            March 2012
--------------------------------------------------------------------------------

This ZIP file contains the U.S. Census Bureau's internal data base providing 
historical statistics on individual city government employment and payrolls 
since 1952.  It also includes data for towns and township governments in 
selected states.

It covers the employment topics of: number of employees, monthly payrolls, 
and two computed statistics, full-time equivalent employment and average 
monthly salary.
 
For more information about the data base, refer to the included User Guide, a 
Microsoft Excel file called: _Emp_Publication_Data_Guide.xls

==========
WHAT'S NEW 
==========

*** Revised data for 2009 (030612):

Revised data for 2009 were inserted into the data base in March 2012.

=============
SPECIAL NOTES
=============

2007 Survey Data:

Effective with the 2007 Employment Survey, a separate table is now available
that provides data flags for each variable and record. These data flags
indicate the source for each variable (reported or imputed). If the variable
was imputed then the imputation method used is indicated by the data flag.

For more information, see the User Guide cited above.
 
==================== 
UNIVERSE DESCRIPTION 
==================== 
 
Individual municipal governments that were published (or qualified for
publication) since 1952 in the annual publication series, "City Employment."
For census of governments years (1957, 1962, and 1967), the census 
publication with individual municipal governments data was used rather
than the annual report.

The criteria for publication have varied over the years, however:

   1952 - 1956, 1962, 1967      Cities with 10,000 or more population
   1957                         Cities with 5,000 or more population*
   1958 and 1959                Cities with 25,000 or more population
   1960 - 1986                  Cities with 50,000 or more population 
                                  (except 1962 and 1967)
   1987 - 1992                  Cities with 75,000 or more population

   *The 1957 publication also showed limited employment data for cities 
    between 2,500 and 5,000 population, but these records were not included
    in this data base.

The last annual "City Employment" report was issued for 1992.  The 1987 
criteria were also used to select records for survey years after 1992.

Also included are town and township governments in selected states where such 
units are similar to cities in organization and local services provided. 

Activities of dependent public school systems are included with the data 
of their parent city, town, or township government.

The 1957 "Compendium of Public Employment" provided data for four cities in
the then-territory of Alaska and for Honolulu, Hawaii.

Note that the availability of data after 1971 for smaller cities depends on
whether they were included in the sample for that year.  Since the population
criteria for automatic inclusion in the sample have increased over the
years to its current 75,000 amount, it is very likely that more recent
data will not be available for the small ones.
 
========================== 
SUBJECT MATTER DESCRIPTION 
========================== 

This data base contains statistics on 81 employment items, although data
are not available for every item for all years

Number of employees and full-time equivalent employment are in whole numbers.
Payroll data are in whole dollars.  The number of employees and payrolls are
also shown for full-time employees.

The payroll statistics are in terms of current dollar amounts as originally
reported. They have not been adjusted for price and wage changes occurring 
through the years.

Beginning with the October 1986 survey data, full-time equivalent employment 
was computed using a new formula based on hours worked by part-time employees.  
Previously, a payroll-based formula was used. Moreover, the payroll-based 
method employed two slightly different formulas between 1952 and 1985.
 
For detailed descriptions and definitions of terms used in this series,
refer to our classification manual which can be accessed on-line here:
 
                www.census.gov/govs/classification/

Population data are in whole numbers. Population data shown are the ones 
that were published at the time of the publication or file's creation.  
These populations may have been revised since their publication.

*** IMPORTANT NOTE:

The primary purpose of this data base is to preserve and make available
in electronic format the statistics on city employment that were published,
especially those reports that predate the availability of any data file 
(i.e., before 1972).

As a result, the employment data items selected for this data base are
limited primarily to those that were published between 1952 and 1992.
In some cases, payroll items were added if the comparable employment
item was published (or vice versa).

The content and format of the city employment reports varied widely between 
1952 and 1992.   This made the creation of a standardized data base structure 
very difficult to achieve.  As a result, data users will find gaps in the 
data presented as well as apparent inconsistencies in the availability of
data for items.   

For example, no data on city government employment for education were published
in the 1962 Compendium of Public Employment.  Also, the number of full-time 
employees for fire protection and for other government administration was 
published for 1957 but no other year before 1972.  Separate employment data for
financial administration were first published in 1961 but then dropped from
the annual reports between 1966 and 1971. Finally, detail on city government 
payrolls is very limited before 1972.
 
============= 
YEARS COVERED 
============= 

This data base covers 1952 to 2010 except for 1996, when no employment
survey was conducted.

As noted below, data before 1972 are extremely limited in detail.
 
============== 
FILE FORMATS
============== 
 
The data base is in Microsoft Access 2000 format and is called
"City_Govt_Emp.mdb."  Its employment items are included in a single
data table.

Although this data base is in Microsoft Access 2000 format, you can easily 
query it using Microsoft Excel.  For instructions, see the enclosed file:

            How_to_Query_MS_Access_DB_in_MS_Excel.xls

The user guide is in Microsoft Excel 2000 format and is called 
"_Emp_Publication_Data_Guide.xls" It is an internal document that may have 
sections or features not relevant to your work. It also contains additional 
notes about the data.

************************************************************
Varying Basis of Presentation for Functional Employment Data
************************************************************

The publication tables showing city employment by function have used three 
different bases since 1952:

 Reports for 1962, 1966, and later years showed full-time equivalent employment
 Reports for 1958 to 1965 (except 1962) showed full-time employees
 Reports for 1952 to 1957 showed total employees (full- and part-time)

In this data base, employment data by function are shown without regard to
their basis.  Instead, a special field ("Basis of Functional Employment Data")
shows whether these data items for a particular year are full-time equivalent
employment ("FTEqE"),  full-time employees ("FTEmp"), or total employees
("TotEmp").

Data users need to be aware of this varying basis of presentation when 
analyzing the changes in the number of employees by function over time. 
Some of the changes observed will be due to the switch in presentation method
rather than employment levels.

This issue has no affect on payroll data.

=====================
OTHER DATA USER NOTES 
=====================

- This data base is an internal file of the U.S. Census Bureau and is shared
with outside data users upon request.

- The data base represents an archive of the data items published in the annual
report series, "City Government Employment," since 1952. These data are based 
on the periodic censuses of governments and annual surveys of public employment.

- The data are based on information from public records and contain no
confidential data.

- Although the governments in this data base may have comprised a sample, the
data themselves are not based (wholly or partly) on a sample and therefore are
not subject to any sampling variability.  The statistical weight (if provided)
is for informational purposes only and should not be used to derive any other
statistics.

- Additional information on nonsampling error, survey design, confidentiality,
and definitions may be found: for 1992 and later years, on our web site 
(www.census.gov) and for earlier years, from the annual report series, "City 
Government Employment," and from the census of governments publications, 
"Employment of Major Local Governments." For 1957 and 1962 these statistics
were published in "Compendium of Public Employment."

- Effective with the 2007 Employment Survey, a separate table is now available
that provides data flags for each variable and record.  These data flags 
indicate the source for each variable (reported or imputed). If the variable
was imputed  then the imputation method used is indicated by the data flag.

- Zero can represent many things: zero amount reported, number rounded to zero,
or function not applicable to a certain level of government for the year
published.

- Amounts reported for "Other and Unallocable" may vary widely from year to
year depending on the level of detail published.  Thus, an increase or decrease
in this category may reflect the inclusion or exclusion  of categories for which
data were reported separately in some years but not others.

- Effective with data for 2003 through 2006, records with imputed data are not
released to the public. Thus, the counts of governments in these files may 
differ from those shown elsewhere. Also, data users wanting to aggregate 
individual records need to be aware that their results will be affected by 
the missing imputed records.

- Data before 1972 are extremely limited in detail. Two flags were inserted 
to indicate missing data:

  A value of "-11111" indicates that the item was not published for that year 

  A value of "-22222" indicates that any amounts are included in "Other
  Government Administration" (used for "Financial Administration" and 
  "Judicial and Legal" functions only).

See User Guide for details.

- To the extent possible, post-publication changes have been applied to the data
base. These include errata notices, corrections notices, memoranda to the files,
and other documented revisions. Also, publication table typos and other obvious
errors were cleaned up.

- Population data shown for individual cities, towns, and townships are the ones
that were published at the time of the publication or file's creation.  These
populations may have been revised since their publication.

- Data users may encounter anomalies discrepancies, or inconsistencies in this
data base, especially in data extracted from publications. Also, data categories
changed over the years. In most cases, these cannot be corrected or even 
explained because the survey materials are no longer available. See user guide 
for details.

- Functions in the data table are arranged in publication order.

- Amounts reported for Other and Unallocable (089) may vary widely from year to 
year depending on the level of detail published. Thus, an increase or decrease 
in this category may reflect the inclusion or exclusion of categories for which
data were reported separately in some years but not others.

- Data in this data base relate only to municipal corporations and their
dependent agencies, and do not include amounts for other local governments
overlying city areas.  In particular, employment figures do not include
those of separate school districts which administer public education in 
most municipal areas.  Variations in the assignment of government 
responsibility for public assistance, health, hospitals, public housing, 
and other functions to a lesser degree also have an important effect upon
reported amounts.

- Data users who create their own estimates using these data should cite the
Census Bureau as the source of the original data only.

- Suggested citation: U.S. Census Bureau, Annual Survey of State and Local
Government Employment and Census of Governments (years)

================================================================================
 
Employment and Benefit Statistics Branch
Governments Division
U.S. Census Bureau
Department of Commerce
Washington, D.C.  20233-6800
(800) 642-4901 
 
=================================== END ========================================
